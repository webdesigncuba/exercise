<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Email</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($contacts->id); ?></th>
                        <td><a href="<?php echo e(route('contacts.show', $contacts->id)); ?>"><?php echo e($contacts->name); ?></a></td>
                        <td><?php echo e($contacts->contact); ?></td>
                        <td><?php echo e($contacts->email); ?></td>
                        <td>
                            <div class="lista">
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('contacts.edit', $contacts->id)); ?>"
                                        class="btn btn-primary btn-sm">Edit</a>

                                    <form action="<?php echo e(route('contacts.destroy', $contacts->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/javier/a/a/exercise/resources/views/contacts/index.blade.php ENDPATH**/ ?>