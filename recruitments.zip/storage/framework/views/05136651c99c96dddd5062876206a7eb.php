<?php $__env->startSection('content'); ?>
    <div class="col-sm">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo e($contacts->name); ?></h5>
            </div>
            <div class="card-body">
                <p class="card-text"><?php echo e($contacts->contact); ?></p>
                <p class="card-text"><?php echo e($contacts->email); ?></p>
            </div>
            <div class="card-footer">
                <div class="row">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="col-sm">
                            <a href="<?php echo e(route('contacts.edit', $contacts->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                        </div>
                        <div class="col-sm">
                            <form action="<?php echo e(route('contacts.destroy', $contacts->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/javier/a/a/exercise/resources/views/contacts/show.blade.php ENDPATH**/ ?>