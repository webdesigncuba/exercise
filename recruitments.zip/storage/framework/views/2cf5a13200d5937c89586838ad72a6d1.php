<?php $__env->startSection('content'); ?>
    <div class="container h-100 mt-5">
        <div class="row h-100 justify-content-center align-items-center">
            <?php echo $__env->make('alert.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 col-md-8 col-lg-6">
                <h3>Update Contact</h3>
                <form action="<?php echo e(route('contacts.update', $contacts->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($contacts->name); ?>"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="contact">Contact</label>
                        <input class="form-control" id="contact" name="contact" value="<?php echo e($contacts->contact); ?>"
                            required></input>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email"
                            value="<?php echo e($contacts->email); ?>" required></input>
                    </div>
                    <button type="submit" class="btn mt-3 btn-primary">Update Contact</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/javier/a/a/exercise/resources/views/contacts/edit.blade.php ENDPATH**/ ?>